from django.shortcuts import render
import openpyxl
import pandas as pd
from django.core.files.storage import FileSystemStorage
from . import readImg

# Create your views here.
def index(req):
    return render(req, 'index.html')

def uploadFile(req):
    file = req.FILES['file']
    fs = FileSystemStorage()
    filename = fs.save(file.name, file)
    print("File :",file.name)
    fileExt = filename.split(".")[-1]
    print("File Extension :",fileExt)
    # uploadedFileUrl = fs.url(filename)
    # wb = openpyxl.load_workbook(excel_file)
    # df = pd.read_csv(filename)

    readImg.readImage(filename)

    # return render(req, 'uploaded.html', {'df' : df})
    return render(req, 'uploaded.html')