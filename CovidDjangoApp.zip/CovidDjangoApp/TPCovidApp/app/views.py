from django.shortcuts import render
import pickle as pkl
import numpy as np

# Create your views here.
def index(request):
    return render(request, 'index.html')

def loadModel(fileName):
    file = open(fileName, 'rb')
    obj = pkl.load(file)
    file.close()
    return obj

def predict(request):
    age = request.GET['age']
    gender = request.GET['gender']
    fever = request.GET['fever']
    bodyPain = request.GET['bodyPain']
    runny_nose = request.GET['runny_nose']
    breath = request.GET['breath']
    nasal = request.GET['nasal']
    sore = request.GET['sore']
    severity = request.GET['severity']
    contact = request.GET['contact']


    genderLabel = loadModel('gender_label.pkl')
    genderOneHot = loadModel('gender_onehot.pkl')

    severityLabel = loadModel('severity_label.pkl')
    severityOneHot = loadModel('severity_onehot.pkl')

    contactLabel = loadModel('contact_label.pkl')
    contactOneHot = loadModel('contact_onehot.pkl')

    st = loadModel('feature_scaling.pkl')

    model = loadModel('model.pkl')

    gender = genderOneHot.transform([genderLabel.transform([gender])]).toarray()
    severity = severityOneHot.transform([severityLabel.transform([severity])]).toarray()
    contact = contactOneHot.transform([contactLabel.transform([contact])]).toarray()
    testX = np.array([[age, fever, bodyPain, runny_nose, breath, nasal, sore]])
    testX = np.c_[testX, gender, severity, contact]
    testX = st.transform(testX)

    pred = model.predict(testX)
    
    if pred[0] == 0:
        msg = "Not Infected..."
    else:
        msg = "Infected..."

    return render(request, 'predict.html', context={'pred' : msg})
