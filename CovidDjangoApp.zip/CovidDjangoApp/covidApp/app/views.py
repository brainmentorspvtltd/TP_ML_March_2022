import re
from django.shortcuts import render

# self - create index method and redirect to index.html
def index(req):
    return render(req, 'index.html')

def login(req):
    name = "Brain Mentors"
    pwd = "123456"
    username = req.GET['username']
    password = req.GET['userpwd']

    if name == username and pwd == password:
        msg = "Login Success..."
    else:
        msg = "Login Failed...Invalid Id or Password"

    return render(req, 'login.html', context={"message" : msg})