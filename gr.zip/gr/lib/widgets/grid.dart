import 'package:flutter/material.dart';
import 'package:veg_fruit_app/widgets/itemrow.dart';
import '../models/item_model.dart';
import '../repository/item_repo.dart';

class Grid extends StatelessWidget {
  // Challenge-2 Unwanted Objects
  ItemRepo _itemRepo = ItemRepo();
  _getProducts() {
    List<ItemModel> items = _itemRepo.getItems();
    return items;
  }

  @override
  Widget build(BuildContext context) {
    // return ItemRow(_getProducts());
    return Container(
      child: Column(
        children: [
          // Challenge -1 This Part need to be Dynamic
          ItemRow(_getProducts()),
          ItemRow(_getProducts()),
          ItemRow(_getProducts()),
        ],
      ),
    );
  }
}
