import 'package:flutter/material.dart';

class GroceryAppBar extends StatelessWidget {
  const GroceryAppBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      leading: Icon(Icons.menu),
      title: Text('Sector-1 , Noida'),
      backgroundColor: Color.fromARGB(255, 172, 172, 19),
    );
  }
}
