import 'package:flutter/material.dart';
import '../models/item_model.dart';
import '../widgets/item.dart';

class ItemRow extends StatelessWidget {
  List<ItemModel> items;
  ItemRow(this.items);
  @override
  Widget build(BuildContext context) {
    // return Row(children: [
    //    // Item(), Item(), Item()
    // ],)
    return Row(
      children:
          items.map((ItemModel item) => Item(item.name, item.url)).toList(),
    );
  }
}
