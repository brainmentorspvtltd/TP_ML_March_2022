import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Banner extends StatelessWidget {
  const Banner({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return Container(
      child: Row(children: [
        SizedBox(
          width: 10,
        ),
        Expanded(
          child: Text(
            'Most Popular',
            style: GoogleFonts.pacifico(
                fontSize: 30, color: Color.fromARGB(255, 117, 14, 6)),
          ),
        ),
        Expanded(
          child: Image.network(
            'https://www.healthyeating.org/images/default-source/home-0.0/nutrition-topics-2.0/general-nutrition-wellness/2-2-2-3foodgroups_fruits_detailfeature.jpg',
          ),
        ),
        SizedBox(
          width: 20,
        ),
      ]),
      height: deviceSize.height * 0.25,
      width: deviceSize.width,
      decoration: BoxDecoration(color: Color.fromARGB(255, 216, 155, 62)),
    );
  }
}
