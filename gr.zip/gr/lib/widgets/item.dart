import 'package:flutter/material.dart';

class Item extends StatelessWidget {
  String url;
  String name;
  Item(this.name, this.url);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.grey.shade200),
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(20),
      height: 100,
      child:
          Column(children: [Expanded(child: Image.network(url)), Text(name)]),
    );
  }
}
