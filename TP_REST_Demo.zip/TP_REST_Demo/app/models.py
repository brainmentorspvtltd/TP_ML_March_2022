from statistics import mode
from django.db import models

# Create your models here.
# Schema of table
class Customers(models.Model):
    c_id = models.IntegerField()
    c_name = models.CharField(max_length=200)
    c_age = models.PositiveIntegerField()