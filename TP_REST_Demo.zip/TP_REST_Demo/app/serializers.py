from attr import fields
from rest_framework import serializers
from .models import Customers

class CustomersSerializers(serializers.ModelSerializer):
    c_id = serializers.IntegerField()
    c_name = serializers.CharField(max_length=200)
    c_age = serializers.IntegerField()

    class Meta:
        model = Customers
        fields = ('__all__')
        # fields = ['c_id', 'c_name']